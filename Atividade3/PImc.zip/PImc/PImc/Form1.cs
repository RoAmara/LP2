﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class IMC : Form

    {
    double Peso, Altura, Imc;

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out Peso)) 
            {
                MessageBox.Show("Peso Invalida");
                mskbxPeso.Focus();
            }
        }

        private void txtIMC_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            Imc = Peso / Math.Pow(Altura, 2);
                Imc = Math.Round(Imc, 1);


            if (Imc < 18.5)
                MessageBox.Show("Magresa");
            else if (Imc < 24.9)
                MessageBox.Show("Normal");
            else if (Imc < 29.9)
                MessageBox.Show("Sobrepeso");
            else if
                (Imc < 39.9)
                MessageBox.Show("Obesidade");

            else
                MessageBox.Show("Obesidade Grave");


        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura .Text, out Altura)) 
            {
                MessageBox.Show("Altura Invalida");
                mskbxAltura.Focus();
            }

        }

        public IMC()
        {
            InitializeComponent();
        }
    }
}
