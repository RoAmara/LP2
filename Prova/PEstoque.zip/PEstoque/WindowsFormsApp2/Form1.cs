﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerif_Click(object sender, EventArgs e)
        {
            int soma1 = 0,soma3=0;
            int[] soma2 = new int[56];
            int[,] vet = new int[56, 4];
            String aux;
            for (int i = 0; i < 56; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    aux = Interaction.InputBox($"Digite o produto da semana{j + 1}", "Entrada de dados");
                    if (!int.TryParse(aux, out vet[i, j]) || vet[i, j] <= 0)
                    {
                        MessageBox.Show("Número inválido!");

                        j--;
                    }

                }
            }
            for (int i = 0; i < 56; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    soma1 += vet[i, j];
                }
                soma2[i] = soma1;
                soma3 += soma2[i];
                soma1 = 0;
            }
            for (int i = 0; i < 56; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    aux = "";
                    aux += $"Total Entradas do Produto:{i + 1} Semana {j+1} -{vet[i,j]}";
                    listBox1.Items.Add(aux);
                }
                aux = "";
                aux += $">>Total Entradas do Produto: {i + 1}                    {soma2[i]}";
                listBox1.Items.Add(aux);
            }
            aux = "";
            aux += $">>Total Geral Entradas                 {soma3}";
            listBox1.Items.Add(aux);

        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
