﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;
using System.Collections;

namespace PTesteMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            string Auxiliar;

            double[,] notas = new double[20, 3];

            for (int i = 0; i < 20; i++)
                for (int j = 0; j < 3; j++)
                {
                    Auxiliar = Interaction.InputBox($"Digite a nota{j+1} do aluno {i+1}", "Entrada de dados");

                    double.TryParse (string "Auxiliar",out notas[i,j]);

                       


            MessageBox.Show("Nota invalida");



        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um Numero {i + 1}numero", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Numero Invalido");
                    i--;
                }
            }

            Array.Reverse(vetor); // inverte o vetor

            auxiliar = "";

            foreach (int i in vetor)
            {
                auxiliar += i +"\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList Nomes = new ArrayList() { "Ana","Andre", "Debora", "Fatima","João","Janete", "Otavio" ,"Marcelo","Pedro","Thais"};

            Nomes.Remove("Otavio");

            string auxiliar = "";

            foreach (string Cont in Nomes )
            {
               auxiliar+=Cont +"\n";
            }


            MessageBox.Show("auxiliar");

        }
    }
}
