﻿namespace PDisaster0030482321034
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.outrosCadastrosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroCidadesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroTipoDeEventosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroEventosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.menuStrip2.Font = new System.Drawing.Font("Sitka Display", 12.25F);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.outrosCadastrosToolStripMenuItem1,
            this.cadastroEventosToolStripMenuItem,
            this.sobreToolStripMenuItem1,
            this.sairToolStripMenuItem1});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(800, 32);
            this.menuStrip2.TabIndex = 2;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // outrosCadastrosToolStripMenuItem1
            // 
            this.outrosCadastrosToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastroCidadesToolStripMenuItem1,
            this.cadastroTipoDeEventosToolStripMenuItem});
            this.outrosCadastrosToolStripMenuItem1.Name = "outrosCadastrosToolStripMenuItem1";
            this.outrosCadastrosToolStripMenuItem1.Size = new System.Drawing.Size(110, 20);
            this.outrosCadastrosToolStripMenuItem1.Text = "Outros Cadastros";
            // 
            // cadastroCidadesToolStripMenuItem1
            // 
            this.cadastroCidadesToolStripMenuItem1.Name = "cadastroCidadesToolStripMenuItem1";
            this.cadastroCidadesToolStripMenuItem1.Size = new System.Drawing.Size(207, 22);
            this.cadastroCidadesToolStripMenuItem1.Text = "Cadastro Cidades";
            this.cadastroCidadesToolStripMenuItem1.Click += new System.EventHandler(this.cadastroCidadesToolStripMenuItem1_Click);
            // 
            // cadastroTipoDeEventosToolStripMenuItem
            // 
            this.cadastroTipoDeEventosToolStripMenuItem.Name = "cadastroTipoDeEventosToolStripMenuItem";
            this.cadastroTipoDeEventosToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.cadastroTipoDeEventosToolStripMenuItem.Text = "Cadastro Tipo de Eventos";
            this.cadastroTipoDeEventosToolStripMenuItem.Click += new System.EventHandler(this.cadastroTipoDeEventosToolStripMenuItem_Click);
            // 
            // cadastroEventosToolStripMenuItem
            // 
            this.cadastroEventosToolStripMenuItem.Name = "cadastroEventosToolStripMenuItem";
            this.cadastroEventosToolStripMenuItem.Size = new System.Drawing.Size(110, 20);
            this.cadastroEventosToolStripMenuItem.Text = "Cadastro Eventos";
            this.cadastroEventosToolStripMenuItem.Click += new System.EventHandler(this.cadastroEventosToolStripMenuItem_Click);
            // 
            // sobreToolStripMenuItem1
            // 
            this.sobreToolStripMenuItem1.Name = "sobreToolStripMenuItem1";
            this.sobreToolStripMenuItem1.Size = new System.Drawing.Size(49, 20);
            this.sobreToolStripMenuItem1.Text = "Sobre";
            this.sobreToolStripMenuItem1.Click += new System.EventHandler(this.sobreToolStripMenuItem1_Click);
            // 
            // sairToolStripMenuItem1
            // 
            this.sairToolStripMenuItem1.Name = "sairToolStripMenuItem1";
            this.sairToolStripMenuItem1.Size = new System.Drawing.Size(49, 28);
            this.sairToolStripMenuItem1.Text = "Sair";
            this.sairToolStripMenuItem1.Click += new System.EventHandler(this.sairToolStripMenuItem1_Click);
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip2);
            this.IsMdiContainer = true;
            this.Name = "frmPrincipal";
            this.Text = "Cadastro de Desastres Naturais";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem outrosCadastrosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cadastroCidadesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cadastroTipoDeEventosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroEventosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem1;
    }
}

