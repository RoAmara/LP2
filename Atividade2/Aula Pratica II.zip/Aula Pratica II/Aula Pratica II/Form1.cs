﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula_Pratica_II
{
    public partial class lblnum2 : Form
    {
        double Num1, Num2, Resultado; // globais

        public lblnum2()
        {
            InitializeComponent();
        }



        private void txtnum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnum1.Text, out Num1)) 
            {
                MessageBox.Show("Num1 invalido!");
                txtnum1.Focus();
            }


        }

      
        private void txtnum2_Validated(object sender, EventArgs e)
        {
          }

        private void btnSub_Click(object sender, EventArgs e)
        {

            Resultado = Num1 - Num2;
            txtnum3.Text = Resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {

            Resultado = Num1*Num2;
            txtnum3.Text = Resultado.ToString();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtnum2_Validated_1(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnum2.Text, out Num2))
            {
                MessageBox.Show("Num2 invalido!");
                txtnum1.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtnum1.Clear();
            txtnum2.Clear();
            txtnum3.Clear();

            Num1 = 0;
            Num2 = 0;
            Resultado = 0;  
                        


        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
    

            Resultado = Num1 + Num2;
            txtnum3.Text = Resultado.ToString();

        }

        private void btnDiv_Click(object sender, EventArgs e)
        {

            if (Num2 == 0)
            {
                MessageBox.Show("Não pode dividir por zero !!!",
                       "erro");
            }
            else
            {

                Resultado = Num1 / Num2;
                txtnum3.Text = Resultado.ToString();
            }
        }

    
    }
}
