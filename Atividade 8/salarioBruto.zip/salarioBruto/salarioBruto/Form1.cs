﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace salarioBruto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Obter as informações fornecidas pelo usuário dos TextBoxes
            string nome = txtNome.Text;
            string matricula = txtGratificacao.Text;
            int producao = Convert.ToInt32(txtSalario.Text);
            double salario = Convert.ToDouble(txtProducao.Text);
            double gratificacao = Convert.ToDouble(txtMatricula.Text);

            // Calcular os valores de B, C e D com base na produção
            int B = producao >= 100 ? 1 : 0;
            int C = producao >= 120 ? 1 : 0;
            int D = producao >= 150 ? 1 : 0;

            // Calcular o salário bruto de acordo com a fórmula fornecida
            double salarioBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

            // Verificar se o salário bruto ultrapassa o limite de 7000 e se há gratificação
            if (salarioBruto > 7000 && (producao < 150 || gratificacao == 0))
            {
                salarioBruto = 7000; // Limitar o salário bruto a 7000 se as condições forem atendidas
            }

            // Exibir o salário bruto calculado em uma MessageBox
            MessageBox.Show($"O salário bruto de {nome} (Matrícula: {matricula}) é: R$ {salarioBruto:F2}");
        }
    }
}
