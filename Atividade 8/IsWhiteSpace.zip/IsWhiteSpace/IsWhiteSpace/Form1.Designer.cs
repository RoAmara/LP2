﻿namespace IsWhiteSpace
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnForLoop = new System.Windows.Forms.Button();
            this.btnForeachLoop = new System.Windows.Forms.Button();
            this.btnWhileLoop = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(26, 23);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(274, 111);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // btnForLoop
            // 
            this.btnForLoop.Location = new System.Drawing.Point(26, 166);
            this.btnForLoop.Name = "btnForLoop";
            this.btnForLoop.Size = new System.Drawing.Size(75, 23);
            this.btnForLoop.TabIndex = 1;
            this.btnForLoop.Text = "For Loop";
            this.btnForLoop.UseVisualStyleBackColor = true;
            this.btnForLoop.Click += new System.EventHandler(this.btnForLoop_Click);
            // 
            // btnForeachLoop
            // 
            this.btnForeachLoop.Location = new System.Drawing.Point(121, 166);
            this.btnForeachLoop.Name = "btnForeachLoop";
            this.btnForeachLoop.Size = new System.Drawing.Size(82, 23);
            this.btnForeachLoop.TabIndex = 2;
            this.btnForeachLoop.Text = "Foreach Loop";
            this.btnForeachLoop.UseVisualStyleBackColor = true;
            this.btnForeachLoop.Click += new System.EventHandler(this.btnForeachLoop_Click);
            // 
            // btnWhileLoop
            // 
            this.btnWhileLoop.Location = new System.Drawing.Point(225, 166);
            this.btnWhileLoop.Name = "btnWhileLoop";
            this.btnWhileLoop.Size = new System.Drawing.Size(75, 23);
            this.btnWhileLoop.TabIndex = 3;
            this.btnWhileLoop.Text = "While Loop";
            this.btnWhileLoop.UseVisualStyleBackColor = true;
            this.btnWhileLoop.Click += new System.EventHandler(this.btnWhileLoop_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnWhileLoop);
            this.Controls.Add(this.btnForeachLoop);
            this.Controls.Add(this.btnForLoop);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnForLoop;
        private System.Windows.Forms.Button btnForeachLoop;
        private System.Windows.Forms.Button btnWhileLoop;
    }
}

