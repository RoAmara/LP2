﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IsWhiteSpace
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnForLoop_Click(object sender, EventArgs e)
        {
            string text = richTextBox1.Text;
            int charCount = 0;
            int spaceCount = 0;
            int rCount = 0;
            int pairCount = 0;

            for (int i = 0; i < text.Length; i++)
            {
                if (!char.IsWhiteSpace(text[i]))
                {
                    charCount++;
                }
                else
                {
                    spaceCount++;
                }

                if (text[i] == 'R' || text[i] == 'r')
                {
                    rCount++;
                }

                if (i < text.Length - 1 && text[i] == text[i + 1])
                {
                    pairCount++;
                }
            }
            MessageBox.Show($"Número de caracteres (com espaços): {charCount}\nNúmero de espaços em branco: {spaceCount}\nNúmero de vezes que 'R' aparece: {rCount}\nNúmero de pares de letras iguais: {pairCount}");
        }

        private void btnForeachLoop_Click(object sender, EventArgs e)
        {
            string text = richTextBox1.Text;
            int charCount = 0;
            int spaceCount = 0;
            int rCount = 0;
            int pairCount = 0;

            foreach (char c in text)
            {
                if (!char.IsWhiteSpace(c))
                {
                    charCount++;
                }
                else
                {
                    spaceCount++;
                }

                if (c == 'R' || c == 'r')
                {
                    rCount++;
                }
            }

            for (int i = 0; i < text.Length - 1; i++)
            {
                if (text[i] == text[i + 1])
                {
                    pairCount++;
                }
            }
            MessageBox.Show($"Número de caracteres (com espaços): {charCount}\nNúmero de espaços em branco: {spaceCount}\nNúmero de vezes que 'R' aparece: {rCount}\nNúmero de pares de letras iguais: {pairCount}");
        }

        private void btnWhileLoop_Click(object sender, EventArgs e)
        {
            string text = richTextBox1.Text;
            int charCount = 0;
            int spaceCount = 0;
            int rCount = 0;
            int pairCount = 0;
            int index = 0;

            while (index < text.Length)
            {
                if (!char.IsWhiteSpace(text[index]))
                {
                    charCount++;
                }
                else
                {
                    spaceCount++;
                }

                if (text[index] == 'R' || text[index] == 'r')
                {
                    rCount++;
                }

                if (index < text.Length - 1 && text[index] == text[index + 1])
                {
                    pairCount++;
                }

                index++;
            }
            MessageBox.Show($"Número de caracteres (com espaços): {charCount}\nNúmero de espaços em branco: {spaceCount}\nNúmero de vezes que 'R' aparece: {rCount}\nNúmero de pares de letras iguais: {pairCount}");
        }
    }
}
