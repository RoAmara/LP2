﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Palíndromo
{
    public partial class txtEntrada : Form
    {
        public txtEntrada()
        {
            InitializeComponent();
        }

        private void buttonVerificação_Click(object sender, EventArgs e)
        {

            // Obter a entrada do usuário do TextBox
            string entrada = textEntrada.Text;

            // Remover espaços em branco e converter para minúsculas
            string entradaSemEspacos = entrada.Replace(" ", "").ToLower();

            // Inverter a sequência de caracteres
            string entradaInvertida = new string(entradaSemEspacos.Reverse().ToArray());

            // Verificar se a entrada original é igual à entrada invertida
            bool ehPalindromo = entradaSemEspacos.Equals(entradaInvertida);

            // Exibir mensagem informando se é um palíndromo ou não
            if (ehPalindromo)
            {
                MessageBox.Show("É um palíndromo!");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo.");
            }
        }
    }
}
