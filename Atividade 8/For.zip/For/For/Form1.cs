﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace For
{
    public partial class txtNumero : Form
    {
        public txtNumero()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textNumero.Text, out int N) && N > 0)
            {
                double H = 0;
                for (int i = 1; i <= N; i++)
                {
                    H += 1.0 / i;
                }
                MessageBox.Show($"O número H é: {H}");
            }
            else
            {
                MessageBox.Show("Por favor, insira um número inteiro positivo válido.");
            }
        }
    }
}
